
package service;


/**
 *
 * @author YOLIMAR
 */
public class Service {

    /**
     * @param args 
     */
    public static void main(String[] args) {
       
       Acceso access = new Acceso();
       access.setVisible(true);
        
       /*Inicio pag_inicio = new Inicio();
       pag_inicio.setVisible(true);*/
    }
    
}
